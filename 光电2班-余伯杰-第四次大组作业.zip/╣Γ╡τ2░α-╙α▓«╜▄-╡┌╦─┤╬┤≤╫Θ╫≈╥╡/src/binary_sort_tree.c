#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

#define true 1
#define false 0
#define succeed 1
#define failed 0
#define Status int

typedef int ElemType;

typedef struct Node {
    ElemType value;
    struct Node* left, * right;
}Node, * NodePtr;

typedef struct BinarySortTree {
    NodePtr root;
} BinarySortTree, * BinarySortTreePtr;

/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
Status BST_init(BinarySortTreePtr T)
{
    T->root = NULL;
}

/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
Status BST_insert(BinarySortTreePtr T, ElemType e)//���õݹ�
{
    if (T->root == NULL)
    {
        Node* s = (Node*)malloc(sizeof(Node));
        if (s == NULL)return failed;
        s->left = NULL;
        s->right = NULL;
        s->value = e;
        T->root = s;
        return succeed;
    }
    BSTinsert(T->root, e);
}
Status BSTinsert(NodePtr node, ElemType e)//�ݹ����
{
    if (node == NULL)
    {
        Node* s = (Node*)malloc(sizeof(Node));
        if (s == NULL)return failed;
        s->left = NULL;
        s->right = NULL;
        s->value = e;
        node = s;
        return succeed;
    }
    else if (e <= node->value)
        BSTinsert(node->left, e);
    else if (e > node->value)
        BSTinsert(node->right, e);
}

/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */
Status BST_delete(BinarySortTreePtr T, ElemType e)
{
    if (T->root == NULL)return failed;
    Node* p = T->root, * f = NULL;//pָ���ɾ��Ԫ�أ�fָ��p���ڵ�
    while (p) {
        if (p->value == e)
        {
            break;
        }
        f = p;
        p = e > p->value ? p->right : p->left;
    }
    if (p == NULL)
    {
        printf("û���������\n");
        return failed;
    }
    //ֻ�����ң�����
    if (p->left == NULL && p->right != NULL)
    {
        if (p->value <= f->value)       //�ж�p��f����
        {
            f->left = p->right;
        }
        else f->right = p->right;
        free(p);
    }
    else  if (p->left != NULL && p->right == NULL)
    {
        if (p->value <= f->value)       //�ж�p��f����
        {
            f->left = p->left;
        }
        else f->right = p->left;
        free(p);
    }
    //ֻ����Ҷ
    else if (p->left == NULL && p->right == NULL)
    {
        if (p->value <= f->value)
        {
            f->left = NULL;
            free(p);
        }
        else
        {
            f->right = NULL;
            free(p);
        }
    }
    //�����������������������ڵ�
    else
    {
        f = p;      //fָ����滻�ڵ�ĸ��ڵ�
        Node* s = p->left;
        while (s->right)
        {
            f = s;
            s = s->right;
        }
        p->value = s->value;
        if (f != p)
        {
            f->right = s->left;
        }
        else
        {
            f->left = s->left;
        }
        free(s);
    }
    printf("��ɾ��\n");
}

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
Status BST_search(BinarySortTreePtr T, ElemType e)
{
    Node* p = T->root;
    while (p != NULL)
    {
        if (e == p->value)return p->value;
        else p = e < p->value ? p->left : p->right;
    }
    return failed;
}

//ջ���ڷǵݹ����
typedef  struct StackNode
{
    ElemType data;
    struct StackNode* next;
}StackNode, * LinkStackPtr;

typedef  struct  LinkStack
{
    LinkStackPtr top;			//ջ��ָ��
}LinkStack;

//��ʼ��ջ
Status initLStack(LinkStack* s) {
    s = (LinkStack*)malloc(sizeof(LinkStack));
    s->top == NULL;
    return succeed;
}
//�п�
Status IsEmpty(LinkStack* s)
{
    if (s->top == NULL)return false;
    else return true;
}
//��ջ
Status pushLStack(LinkStack* s, Node* x) {
    LinkStackPtr n = (StackNode*)malloc(sizeof(StackNode));
    if (n == NULL)
        return failed;
    n->data = x->value;
    n->next = s->top;
    s->top = n;
    return succeed;
}

//��ջ
Status popLStack(LinkStack* s, Node* x) {
    LinkStackPtr p = s->top;
    x->value = s->top->data;
    s->top = s->top->next;
    free(p);
    return succeed;
}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_preorderI(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    LinkStack s;            //����ջ
    initLStack(&s);
    Node* p = T->root;//p����
    while (p != NULL || IsEmpty(&s))
    {
        if (p != NULL)              //��������ջ
        {
            visit(p);
            pushLStack(&s, p);
            p = p->left;
        }
        else
        {
            popLStack(&s, p);        //��Ϊ�ճ�ջ
            p = p->right;           //��վpָ���Һ�
        }
    }
}

/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_preorderR(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    Node* node = T->root;
    BSTpreorderR(node, visit);
}

Status BSTpreorderR(NodePtr node, void (*visit)(NodePtr))
{
    if (node != NULL)
    {
        visit(node);
        BSTpreorderR(node->left, visit);
        BSTpreorderR(node->right, visit);
    }
    else return failed;
}

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_inorderI(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    LinkStack s;            //����ջ
    initLStack(&s);
    Node* p = T->root;      //p����
    while (p != NULL || IsEmpty(&s))
    {
        if (p != NULL)
        {
            pushLStack(&s, p);
            p = p->left;
        }
        else
        {
            popLStack(&s, p);
            visit(p);
            p = p->right;
        }
    }
}

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_inorderR(NodePtr node, void (*visit)(NodePtr))
{
    if (node != NULL)
    {
        BST_preorderR(node->left, visit);
        visit(node);
        BST_preorderR(node->right, visit);
    }
    else return failed;

}

/**
 * BST postorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_postorderI(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    LinkStack s1, s2;   //s1��2�η��ʽڵ�������
    initLStack(&s1);
    initLStack(&s2);    //�ű������
    Node* p = T->root;//p����
    while (p != NULL || IsEmpty(&s1))
    {
        while (p != NULL)
        {
            pushLStack(&s2, p);
            pushLStack(&s1, p);
            p = p->right;           //�����Һ�
        }
        if (IsEmpty(&s1))//���Һ�������s2ջ
        {
            popLStack(&s1, p);
            p = p->left;
        }
    }
    while (IsEmpty(&s2))
    {
        popLStack(&s2, p);
        visit(p);
    }
}
/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_postorderR(NodePtr node, void (*visit)(NodePtr))
{
    if (node != NULL)
    {
        BST_preorderR(node->left, visit);
        BST_preorderR(node->right, visit);
        visit(node);
    }
    else return failed;

}

////�������ڲ�α���
//typedef struct Node {					//�������Ԫ��
//    void* data;							//������
//    struct Node* next;
//}Node;
//
//typedef struct Queue {					//�������
//    Node* head;							//ָ��ͷ�ڵ�
//    Node* tail;							//ָ��β�ڵ�
//}Queue;
//
//void EnQueue(Queue* Q, void* data)		//��β�ڵ����
//{
//    Node* s = (Node*)malloc(sizeof(Node));//�½ڵ�s
//    s->data = data;
//    s->next = NULL;
//    if (Q->head == NULL)
//    {
//        Q->head = s;
//        Q->tail = s;
//    }
//    else
//    {
//        Q->tail->next = s;
//        Q->tail = Q->tail->next;		//tail��β�ƶ�
//    }
//}
//
//void* DeQueue(Queue* Q)		//��ͷ����
//{
//    if (Q->head == NULL)
//    {
//        return NULL;
//    }
//    Node* p = Q->head;
//    Q->head = p->next;
//    void* data = p->data;
//    free(p);
//    return data;
//}
/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
//Status BST_levelOrder(BinarySortTreePtr, void (*visit)(NodePtr));

void pr(BinarySortTreePtr T)
{
    Node* node = T->root;
    while (node != NULL)
    {
        printf("%d ", node->value);
        node = node->left;
    }
}