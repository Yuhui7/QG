#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define _Calculator_H_

typedef struct ListNode {					//����ջ
	int num;
	struct ListNode* next;
}ListNode, * ListStack;

int main()
{
	int x=0;
	ListNode* N;								//����ջͷָ��N
	N = (ListNode*)malloc(sizeof(ListNode));
	N->next = NULL;

	while (1)
	{
		printf("���ܣ�\n");
		scanf("%d", &x);
		switch (x)
		{
			
		case 1:NumPush(N);break;
		case 2:NumPop( N); break;
		default:printf("�޴˹���\n");
		}
	}
}