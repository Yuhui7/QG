#ifndef _Calculator_H_
#define _Calculator_H_

typedef struct ListNode {					//����ջ
	int num;
	struct ListNode* next;
}ListNode, * ListStack;

void NumPush(ListStack N);
void NumPop(ListStack N);
#endif