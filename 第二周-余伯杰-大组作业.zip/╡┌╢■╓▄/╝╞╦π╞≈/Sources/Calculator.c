#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct NumNode {					//����ջ
	int num;
	struct NumNode* next;
}NumNode, * NumStack;

typedef struct OpNode {						//�����ջ
	char opera;
	struct OpNode* next;
}OpNode, * OperaStack;


void NumPush(NumStack N,int a)
{
	NumStack s;
	s = (NumNode*)malloc(sizeof(NumNode));//�½��ڵ�s
	s->num = a;
	s->next = N->next;
	N->next = s;
}

void OpPush(OperaStack O,char c)
{
	OperaStack s;
	s = (OpNode*)malloc(sizeof(OpNode));
	s->opera = c;
	s->next = O->next;
	O->next = s;
}

int NumPop(NumStack N)
{
	int a;
	NumStack top = N->next;				//topָ��ջ��
	a = top->num;
	if (top != NULL)
	{
		N->next = top->next;
	}	
	free(top);
	return a;
}

char OpPop(OperaStack O)
{
	char c;
	OperaStack top = O->next;				//topָ��ջ��	
	c = top->opera;	
	if (top != NULL)
	{
		O->next = top->next;
	}
	free(top);
	return c;
}

int Operate(int left, int right, char opera)
{
	int result = 0;
	switch (opera)
	{
	case '+':result = left + right; break;
	case '-':result = left - right; break;
	case '*':result = left * right; break;
	case '/':result = left / right; break;
	}
	return result;
}

int Priority(char a)						//���ݷ������ִ�Сȷ�����ȼ�
{
	switch (a)
	{

	case '+':
	case '-':
		return 1;
	case '*':
	case '/':
		return 2;
	case '��':
	case ')':
		return 3;
	}
}

char GetOpTop(OperaStack O)							//��ȡ�����ջ��Ԫ��
{
	OperaStack top = O->next;						//topָ��ջ��
	if (top == NULL)return 0;
	return top->opera;
}