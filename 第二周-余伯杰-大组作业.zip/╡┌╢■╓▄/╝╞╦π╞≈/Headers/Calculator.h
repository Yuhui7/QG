#ifndef _Calculator_H_
#define _Calculator_H_

typedef struct NumNode {					//����ջ
	float num;
	struct NumNode* next;
}NumNode, * NumStack;

typedef struct OpNode {						//�����ջ
	char opera;
	struct OpNode* next;
}OpNode, * OperaStack;

void NumPush(NumStack N, float a);
void OpPush(OperaStack O, char c);
float NumPop(NumStack N);
char OpPop(OperaStack O);
float Operate(float left, float right, char opera);
int Priority(char a);
char GetOpTop(OperaStack O);


#endif