#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

typedef enum Status
{
	ERROR = 0,
	SUCCESS = 1
} Status;

typedef int ElemType;

typedef  struct StackNode
{
	ElemType data;
	struct StackNode* next;
}StackNode, * LinkStackPtr;

typedef  struct  LinkStack
{
	LinkStackPtr top;			//ջ��ָ��
	int	count;					//����
}LinkStack;

//��ʼ��ջ
Status initLStack(LinkStack* s) {
	s = (LinkStack*)malloc(sizeof(LinkStack));
	s->top == NULL;
	s->count = 0;
	return SUCCESS;
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyLStack(LinkStack* s) {
	if (s->count == 0)return ERROR;
	return SUCCESS;
}

//�õ�ջ��Ԫ��
Status getTopLStack(LinkStack* s) {
	int e;
	if (s->top != NULL)
	{
		e = s->top->data;
		printf("ջ�����ݣ�%d\n", e);
		return SUCCESS;
	}
	return ERROR;
}

//���ջ
Status clearLStack(LinkStack* s) {
	LinkStackPtr p, q;			//ָ��p,q�������
	p = s->top;
	while (p)
	{
		q = p->next;
		free(p);
		p = q;
	}
	s->count = 0;
	s->top = NULL;
	return SUCCESS;
}

//����ջ
Status destroyLStack(LinkStack* s) {
	if (s == NULL)
	{
		printf("ջ������\n");
		return SUCCESS;
	}
	clearLStack(s);
	destroyLStack(s);
}

//���ջ����
Status LStackLength(LinkStack* s){
	int length;
	length = s->count;
	printf("ջ���ȣ�%d\n", length);
	return SUCCESS;
}

//��ջ
Status pushLStack(LinkStack* s, ElemType data) {
	LinkStackPtr n = (StackNode*)malloc(sizeof(StackNode));
	if (n == NULL)
		return ERROR;
	n->data = data;
	n->next = s->top;
	s->top= n;
	s->count++;
	return SUCCESS;
}

//��ջ
Status popLStack(LinkStack* s) {
	LinkStackPtr p = s->top;
	int data;
	data= s->top->data;
	s->top = s->top->next;
	free(p);
	s->count--;
	printf("��ջ���ݣ�%d\n", data);
	return SUCCESS;
}