#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define SORT_H_INCLUDED
#include<time.h>
#define N 10000

void creatdata()
{
	srand((unsigned int)time(NULL));
	int a[N];
	int size = sizeof(a) / sizeof(int);
	for (int i = 0; i < N; i++)a[i] = rand();
	FILE* fp = fopen("�����.txt", "w");
	for (int i = 0; i < N; i++)
	{
		fprintf(fp, "%d\t",a[i]);
	}
	fclose(fp);
}