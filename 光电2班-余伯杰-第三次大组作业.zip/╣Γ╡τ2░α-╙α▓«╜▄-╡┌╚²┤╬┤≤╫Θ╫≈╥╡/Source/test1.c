#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define SORT_H_INCLUDED
#include<time.h>
#define N 10000
#define M 50000
#define K 200000

void testtimeN()
{	//��ʼ��	
	int a[N];
	int size = sizeof(a) / sizeof(int);
	FILE* fp = fopen("�����.txt", "r");
	for (int i = 0; i < N; i++)
	{
		fscanf(fp, "%d\t", &a[i]);
	}
	fclose(fp);

	clock_t start1 = 0, end1 = 0;
	//clock_t start2 = 0, end2 = 0;
	//clock_t start3 = 0, end3 = 0;
	//clock_t start4 = 0, end4 = 0;
	double sorttime1;
	//double sorttime2;
	//double sorttime3;
	//double sorttime4;
	sorttime1 = (double)(end1 - start1) / CLK_TCK;
	//sorttime2 = (double)(end2 - start2) / CLK_TCK;
	//sorttime3 = (double)(end3 - start3) / CLK_TCK;
	//sorttime4 = (double)(end4 - start4) / CLK_TCK;
	//����
	start1 = clock();
	insertSort(a, size);
	end1 = clock();
	////�鲢	

	//start2 = clock();
	//Merge_Sort(a, size);
	//end2 = clock();
	////����	

	////for (int i = 0; i < N; i++)a[i] = rand();

	//start3 = clock();
	//QuickSort_Recursion(a, 0, size - 1);
	//end3 = clock();
	////����	

	////for (int i = 0; i < N; i++)a[i] = rand();

	//start4 = clock();
	//CountSort(a, size);
	//end4 = clock();
//	for (int i = 0; i < N; i++)printf("%.7d\t", a[i]);
	printf("\n*******************\n");
	printf("����������%lf��\n", sorttime1);
	printf("*******************\n");
	/*printf("\n*******************\n");
	printf("�鲢������%lf��\n", sorttime2);
	printf("*******************\n");
	printf("\n*******************\n");
	printf("����������%lf��\n", sorttime3);
	printf("*******************\n");
	printf("\n*******************\n");
	printf("����������%lf��\n", sorttime4);
	printf("*******************\n");*/
}
//
//void testtimeM()
//{	//��ʼ��
//	int a[M];
//	int size = sizeof(a) / sizeof(int);
//	clock_t start1 = 0, end1 = 0;
//	clock_t start2 = 0, end2 = 0;
//	clock_t start3 = 0, end3 = 0;
//	clock_t start4 = 0, end4 = 0;
//	double sorttime1;
//	double sorttime2;
//	double sorttime3;
//	double sorttime4;
//	sorttime1 = (double)(end1 - start1) / CLOCKS_PER_SEC;
//	sorttime2 = (double)(end2 - start2) / CLOCKS_PER_SEC;
//	sorttime3 = (double)(end3 - start3) / CLOCKS_PER_SEC;
//	sorttime4 = (double)(end4 - start4) / CLOCKS_PER_SEC;
//	//����
//
//	for (int i = 0; i < M; i++)a[i] = rand();
//
//	start1 = clock();
//	insertSort(a, size);
//	end1 = clock();
//	//�鲢	
//
////	for (int i = 0; i < M; i++)a[i] = rand();
//
//	start2 = clock();
//	Merge_Sort(a, size);
//	end2 = clock();
//	//����	
//
////	for (int i = 0; i < M; i++)a[i] = rand();
//
//	start3 = clock();
//	QuickSort_Recursion(a, 0, size - 1);
//	end3 = clock();
//	//����	
////	for (int i = 0; i < M; i++)a[i] = rand();
//
//	start4 = clock();
//	CountSort(a, size);
//	end4 = clock();
//
//	printf("\n*******************\n");
//	printf("����������%lf��\n", sorttime1);
//	printf("*******************\n");
//	printf("\n*******************\n");
//	printf("�鲢������%lf��\n", sorttime2);
//	printf("*******************\n");
//	printf("\n*******************\n");
//	printf("����������%lf��\n", sorttime3);
//	printf("*******************\n");
//	printf("\n*******************\n");
//	printf("����������%lf��\n", sorttime4);
//	printf("*******************\n");
//}
//
//void testtimeK()
//{	//��ʼ��		
//	int a[K];
//	int size = sizeof(a) / sizeof(int);
//	clock_t start1 = 0, end1 = 0;
//	clock_t start2 = 0, end2 = 0;
//	clock_t start3 = 0, end3 = 0;
//	clock_t start4 = 0, end4 = 0;
//	double sorttime1;
//	double sorttime2;
//	double sorttime3;
//	double sorttime4;
//	sorttime1 = (double)(end1 - start1) / CLOCKS_PER_SEC;
//	sorttime2 = (double)(end2 - start2) / CLOCKS_PER_SEC;
//	sorttime3 = (double)(end3 - start3) / CLOCKS_PER_SEC;
//	sorttime4 = (double)(end4 - start4) / CLOCKS_PER_SEC;
//	//����
//
//	for (int i = 0; i < K; i++)a[i] = rand();
//
//	start1 = clock();
//	insertSort(a, size);
//	end1 = clock();
//	//�鲢	
//
//	for (int i = 0; i < K; i++)a[i] = rand();
//
//	start2 = clock();
//	Merge_Sort(a, size);
//	end2 = clock();
//	//����	
//
//	for (int i = 0; i < K; i++)a[i] = rand();
//
//	start3 = clock();
//	QuickSort_Recursion(a, 0, size - 1);
//	end3 = clock();
//	//����	
//
//	for (int i = 0; i < K; i++)a[i] = rand();
//
//	start4 = clock();
//	CountSort(a, size);
//	end4 = clock();
//
//	printf("\n*******************\n");
//	printf("����������%lf��\n", sorttime1);
//	printf("*******************\n");
//	printf("\n*******************\n");
//	printf("�鲢������%lf��\n", sorttime2);
//	printf("*******************\n");
//	printf("\n*******************\n");
//	printf("����������%lf��\n", sorttime3);
//	printf("*******************\n");
//	printf("\n*******************\n");
//	printf("����������%lf��\n", sorttime4);
//	printf("*******************\n");
//}

void test1(void)
{
	int x = 0;
	srand((unsigned int)time(NULL));
	printf("ѡ����������1.10000	2.50000	3.200000��\n");
	scanf("%d", &x);
		switch (x)
		{
		case 1:testtimeN();	break;
		//case 2:testtimeM();	break;
		//case 3:testtimeK();	break;
		}
}