#ifndef _DELAY_H_
#define _DELAY_H_

void Delay(unsigned int xms);


#endif