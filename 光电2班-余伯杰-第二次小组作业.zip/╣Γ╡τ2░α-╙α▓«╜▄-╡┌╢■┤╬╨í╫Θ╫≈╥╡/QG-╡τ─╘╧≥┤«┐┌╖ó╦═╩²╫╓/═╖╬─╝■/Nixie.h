#ifndef _NIXIE_H_
#define _NIXIE_H_

void nixie(unsigned char loca,x);


#endif