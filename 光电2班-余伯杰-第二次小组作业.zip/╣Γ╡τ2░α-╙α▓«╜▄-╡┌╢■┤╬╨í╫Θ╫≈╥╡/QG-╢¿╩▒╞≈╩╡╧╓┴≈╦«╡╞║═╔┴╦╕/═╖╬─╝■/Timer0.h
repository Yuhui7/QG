#ifndef _TIMER0_H_
#define _TIMER0_H_

void Timer0Init(void);

#endif