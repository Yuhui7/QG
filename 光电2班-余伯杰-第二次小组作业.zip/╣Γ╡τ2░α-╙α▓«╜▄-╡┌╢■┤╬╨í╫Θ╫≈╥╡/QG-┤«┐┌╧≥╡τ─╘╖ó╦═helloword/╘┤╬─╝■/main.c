#include <REGX52.H>
#include  "UART.h"
#include "Delay.h"

unsigned char a[11]="helloword ";

void main()
{	
	UartInit();		//��ʼ��
	while(1)
		{	
			Delay(500);
			UART_SendString(a);
			Delay(500);
		}
}