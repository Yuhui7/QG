#ifndef _UART_H_
#define _UART_H_

void UartInit();	
void UART_SendByte(unsigned char Byte);
void UART_SendString(unsigned char*str);

#endif